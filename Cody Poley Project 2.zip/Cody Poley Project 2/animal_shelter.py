from pymongo import MongoClient 
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:46909' % (username, password))
        self.database = self.client['AAC'] 
        
     #Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None: # if data is not empty
            checkInsert = self.database.animals.insert(data) # Insert data and return value of 1 or 0 
            # if value was add, 1 equals true and 0 equals false
            if checkInsert == 1: 
                return True
            else:
                return False
        else: # if data is empty error message
            raise Exception("Nothing to save, because data parameter is empty")
            
    # read database      
    def read(self, data):
        if data is not None: # if data is not empty
            result = self.database.animals.find(data, {"_id": False}) # find data in database and get result
            return result #return result of find
        else: # if data is empty error message
            raise Exception("Nothing to find, because data parameter is empty")
           
    # update database    
    def update(self, key, data):
        if data is not None and key is not None: #update if values key and data are not None
            result = self.database.animals.update_many(key, {"$set":data}) # update all with key with data
            updateResult = str(result)
            return json.dumps(updateResult)
        else: # if data or key are empty error message
            raise Exception("Nothing to update, because data parameter is empty")
         
    # delete from database    
    def delete(self, data):
        if data is not None: # if data is not empty
            result = json.dumps(str(self.database.animals.delete_many(data))) #delete all with data parameters
            deleteResult = str(result)
            return json.dumps(deleteResult)
        else: # if  data empty error message
            raise Exception("Nothing to delete, because data parameter is empty")
    
        
                                